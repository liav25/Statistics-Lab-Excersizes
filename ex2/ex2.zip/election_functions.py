# Functions for Loading and analysis of election data
# Modified from a python notebook from Harel Kein
# Call libraries
import pandas as pd
import numpy as np
import os
from matplotlib import pyplot as plt

pd.set_option('display.max_rows',10000000)


# Path to datafile - change to your directory!
DATA_PATH = 'C:/Users/Or Zuk/Google Drive/HUJI/Teaching/Lab_52568/Data/Elections'


# Functions
# Get number of votes of all parties
def parties_votes_total(df, thresh):
    par = df.sum().sort_values(ascending=False)
    return par[par > thresh]


# Get votes of all parties (normalized)
def parties_votes(df, thresh):
    par = df.sum().div(df.sum().sum()).sort_values(ascending=False)
    return par[par > thresh]


# Bar plot for all parties with votes above a threshold
def parties_bar(df, thresh, city):
    width = 0.3
    votes = parties_votes(df, thresh)  # total votes for each party
    n = len(votes)  # number of parties
    names = votes.keys()

    rev_names = [name[::-1] for name in list(names)]
    fig, ax = plt.subplots()  # plt.subplots()

    city_votes = df.loc[city,names] / df.loc[city,names].sum()
    all_bar = ax.bar(np.arange(n), list(votes), width, color='b')
    city_bar = ax.bar(np.arange(n)+width, list(city_votes), width, color='r')

    ax.set_ylabel('Votes percent')
    ax.set_xlabel('Parties Names')
    ax.set_title('Votes percent per party 2019')
    ax.set_xticks(np.arange(n))
    ax.set_xticklabels(rev_names)
    ax.legend((all_bar[0], city_bar[0]), ('Israel', city[::-1]))
    plt.show()

    return fig, ax


# Plot histogram of votes for a particular party across all cities
def one_party_hist(df, party, nbins):
    votes_per_city = df.sum(axis=1)
    party_share = df[party] / votes_per_city

    plt.hist(party_share, nbins)
    plt.xlabel('Num. Votes')
    plt.ylabel('Freq.')
    plt.title('Histogram of ' + party[::-1])
    plt.show()


# Show party votes vs. city size
def party_size_scatter(df, party):
    votes_per_city = df.sum(axis=1)
    party_share = df[party] / votes_per_city

    plt.scatter(votes_per_city, party_share)
    plt.xlabel('Total Votes')
    plt.ylabel('Party %')
    plt.title('Votes for ' + party[::-1])
    plt.show()



# Show party votes for two parties
def party_party_scatter(df, party1, party2):
    votes_per_city = df.sum(axis=1)
    party_share1 = df[party1] / votes_per_city
    party_share2 = df[party2] / votes_per_city

    plt.scatter(party_share1, party_share2)  # Here draw circles with area proportional to city size
    plt.xlabel(party1[::-1])
    plt.ylabel(party2[::-1])
    plt.title('Scatter for two parties ' )
    plt.show()

#rescaling a column
def rescaling(column , a, b):
    min_value = column.min()
    max_value = column.max()
    x_norm = column.apply( lambda x: (b-a)*((x-min_value)/(max_value-min_value)) + a )
    return x_norm

def party_party_city_size_scatter(df, party1, party2,a=0,b=200):
    votes_per_city = df.sum(axis=1)
    party_share1 = df[party1] / votes_per_city
    party_share2 = df[party2] / votes_per_city
    norm_votes = rescaling(df['מצביעים'], a, b)

    alphas = rescaling(norm_votes,0.7,0.5)
    rgba_colors = np.zeros((1214, 4))
    # for red the first column needs to be one
    rgba_colors[:, 0] = 0.3
    rgba_colors[:, 2] = 0.7

    # the fourth column needs to be your alphas
    rgba_colors[:, 3] = alphas


    plt.scatter(party_share1, party_share2, s=norm_votes, color=rgba_colors)  # Here draw circles with area proportional to city size
    plt.xlabel(party1[::-1])
    plt.ylabel(party2[::-1])
    plt.title('Scatter for two parties, Dot proportional to total voters')
    plt.show()

def estimate_total_votes(df):
    n_dot = df['כשרים']
    n_tilda = df['בזב']
    n = df['בזב'].sum()